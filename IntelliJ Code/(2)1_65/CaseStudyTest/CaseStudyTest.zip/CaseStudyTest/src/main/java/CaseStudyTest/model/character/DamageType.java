package CaseStudyTest.model.character;

public enum DamageType {
    physical,
    magical,
    astral
}

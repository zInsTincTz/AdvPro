package CurrencyStudy.controller.draw;

public class DrawTopAreaTask {
}
